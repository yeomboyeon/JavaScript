'use strict';

console.clear();

// 좌,우 버튼을 눌렸을 때 하단 박스가 좌,우로 움직이도록
// 구현해야 함
// 선택자 eq(), if문, length-1(인덱스번호), removeclass, addclass
// 변수 선언 : 2가지(기본, 라스트)

let a = 0;
const lasta = $('.sams > div').length-1;

$('.cat > button').eq(0).click(function(){ // 버튼 좌 선택
    if($(a === 0)){ // 좌를 선택했다면
        a = lasta; // 좌로 움직여라
    }else { // 그게 아니면
        a--; // 1씩 감소
    }
    $('.sams > div').removeclass('.sams > .action'); // div 박스 중에서 action을 삭제 시켜라
    $('.sams > div').eq(a).addclass('.sams > .action'); // div 박스 중 a를 선택해서 action을 추가 시켜라    
})


// $('section > button').eq(1).click(function(){ // 버튼 우 선택
//     if($(a === lasta)){ // 우를 선택했다면
//         a = 0; // 우로 움직여라
//     }else { // 그게 아니면
//         a++; // 1씩 증가
//     }
//     $('.sams > div').removeclass('.action'); // div 박스 중에서 action을 삭제 시켜라
//     $('.sams > div').eq(a).addclass('.action'); // div 박스 중 a를 선택해서 action을 추가 시켜라    
// })
